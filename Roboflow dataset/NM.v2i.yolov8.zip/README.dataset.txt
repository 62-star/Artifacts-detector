# NM > 2024-06-17 2:00pm
https://universe.roboflow.com/rowida-abdelkhalek/nm-lyqch

Provided by a Roboflow user
License: CC BY 4.0

